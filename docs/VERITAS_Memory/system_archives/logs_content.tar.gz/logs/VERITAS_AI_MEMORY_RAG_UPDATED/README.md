# Rob's AI Assistant Memory System

## Overview
This is a comprehensive RAG (Retrieval-Augmented Generation) memory system designed to maintain context, track learning, and ensure truth-based interactions.

## Directory Structure

### `/core_principles/`
- `truth_protocol.json` - Core truth protocol data
- `truth_protocol.md` - Human-readable documentation

### `/project_data/`
- `projects.json` - All project tracking data

### `/personal_context/`
- `rob_profile.json` - Rob's preferences, working style, communication patterns

### `/knowledge_base/`
- `knowledge_base.json` - Verified facts vs assumptions, tested vs theoretical

### `/interaction_logs/`
- `interaction_log.json` - Key conversations, decisions, outcomes

### `/lessons_learned/`
- `lessons.json` - Structured lessons learned from interactions

## Core Principle
**"I don't know" is always better than confident bullshit**

This system is built on the foundation of truth, explicit uncertainty acknowledgment, and continuous learning.

## Usage
This is a living system that should be updated with each significant interaction, lesson learned, or project development.

## Last Updated
2025-07-07 08:14:03