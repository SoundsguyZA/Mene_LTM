import logging
import logging.handlers
import os
import sys
import json
import traceback
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional, Union
import threading
from contextlib import contextmanager

class ColoredFormatter(logging.Formatter):
    """
    Custom formatter that adds colors to log levels for console output
    """

    # ANSI color codes
    COLORS = {
        'DEBUG': '[36m',      # Cyan
        'INFO': '[32m',       # Green
        'WARNING': '[33m',    # Yellow
        'ERROR': '[31m',      # Red
        'CRITICAL': '[35m',   # Magenta
        'RESET': '[0m'        # Reset
    }

    def format(self, record):
        # Add color to levelname
        if hasattr(record, 'levelname') and record.levelname in self.COLORS:
            colored_levelname = f"{self.COLORS[record.levelname]}{record.levelname}{self.COLORS['RESET']}"
            record.levelname = colored_levelname

        return super().format(record)

class JSONFormatter(logging.Formatter):
    """
    Custom formatter that outputs logs in JSON format for structured logging
    """

    def format(self, record):
        # Create base log entry
        log_entry = {
            'timestamp': datetime.utcnow().isoformat() + 'Z',
            'level': record.levelname,
            'logger': record.name,
            'message': record.getMessage(),
            'module': record.module,
            'function': record.funcName,
            'line': record.lineno,
            'thread': record.thread,
            'thread_name': record.threadName,
            'process': record.process
        }

        # Add exception information if present
        if record.exc_info:
            log_entry['exception'] = {
                'type': record.exc_info[0].__name__,
                'message': str(record.exc_info[1]),
                'traceback': traceback.format_exception(*record.exc_info)
            }

        # Add extra fields if present
        if hasattr(record, 'extra_fields'):
            log_entry.update(record.extra_fields)

        # Add agent-specific fields if present
        if hasattr(record, 'agent_name'):
            log_entry['agent'] = record.agent_name

        if hasattr(record, 'request_id'):
            log_entry['request_id'] = record.request_id

        if hasattr(record, 'user_id'):
            log_entry['user_id'] = record.user_id

        if hasattr(record, 'session_id'):
            log_entry['session_id'] = record.session_id

        return json.dumps(log_entry, ensure_ascii=False)

class AgentLoggerAdapter(logging.LoggerAdapter):
    """
    Logger adapter that adds agent-specific context to log messages
    """

    def __init__(self, logger, agent_name: str):
        super().__init__(logger, {'agent_name': agent_name})
        self.agent_name = agent_name

    def process(self, msg, kwargs):
        # Add agent name to extra fields
        if 'extra' not in kwargs:
            kwargs['extra'] = {}

        kwargs['extra']['agent_name'] = self.agent_name

        # Add agent prefix to message
        return f"[{self.agent_name.upper()}] {msg}", kwargs

    def log_interaction(self, user_message: str, response: str, response_time: float = None, **kwargs):
        """Log agent interaction with structured data"""
        extra_fields = {
            'interaction_type': 'agent_response',
            'user_message_length': len(user_message),
            'response_length': len(response),
            'agent_name': self.agent_name
        }

        if response_time:
            extra_fields['response_time_seconds'] = response_time

        extra_fields.update(kwargs)

        self.info(
            f"Interaction completed - User: {user_message[:100]}... Response: {response[:100]}...",
            extra={'extra_fields': extra_fields}
        )

    def log_browser_action(self, action: str, selector: str = None, success: bool = True, **kwargs):
        """Log browser automation actions"""
        extra_fields = {
            'action_type': 'browser_action',
            'action': action,
            'success': success,
            'agent_name': self.agent_name
        }

        if selector:
            extra_fields['selector'] = selector

        extra_fields.update(kwargs)

        level = logging.INFO if success else logging.WARNING
        message = f"Browser action: {action}"
        if selector:
            message += f" (selector: {selector})"
        message += f" - {'Success' if success else 'Failed'}"

        self.log(level, message, extra={'extra_fields': extra_fields})

class RequestLoggerAdapter(logging.LoggerAdapter):
    """
    Logger adapter that adds request-specific context to log messages
    """

    def __init__(self, logger, request_id: str, user_id: str = None):
        super().__init__(logger, {'request_id': request_id, 'user_id': user_id})
        self.request_id = request_id
        self.user_id = user_id

    def process(self, msg, kwargs):
        # Add request context to extra fields
        if 'extra' not in kwargs:
            kwargs['extra'] = {}

        kwargs['extra']['request_id'] = self.request_id
        if self.user_id:
            kwargs['extra']['user_id'] = self.user_id

        # Add request ID prefix to message
        prefix = f"[REQ:{self.request_id[:8]}]"
        if self.user_id:
            prefix += f"[USER:{self.user_id}]"

        return f"{prefix} {msg}", kwargs

class PerformanceLogger:
    """
    Logger for performance metrics and monitoring
    """

    def __init__(self, logger: logging.Logger):
        self.logger = logger
        self._metrics = {}
        self._lock = threading.Lock()

    @contextmanager
    def timer(self, operation_name: str, **context):
        """Context manager for timing operations"""
        start_time = datetime.utcnow()

        try:
            yield
            success = True
            error = None
        except Exception as e:
            success = False
            error = str(e)
            raise
        finally:
            end_time = datetime.utcnow()
            duration = (end_time - start_time).total_seconds()

            self.log_performance(
                operation_name=operation_name,
                duration_seconds=duration,
                success=success,
                error=error,
                **context
            )

    def log_performance(self, operation_name: str, duration_seconds: float, 
                       success: bool = True, error: str = None, **context):
        """Log performance metrics"""

        extra_fields = {
            'metric_type': 'performance',
            'operation': operation_name,
            'duration_seconds': duration_seconds,
            'success': success
        }

        if error:
            extra_fields['error'] = error

        extra_fields.update(context)

        # Update internal metrics
        with self._lock:
            if operation_name not in self._metrics:
                self._metrics[operation_name] = {
                    'count': 0,
                    'total_time': 0,
                    'success_count': 0,
                    'error_count': 0
                }

            metrics = self._metrics[operation_name]
            metrics['count'] += 1
            metrics['total_time'] += duration_seconds

            if success:
                metrics['success_count'] += 1
            else:
                metrics['error_count'] += 1

        # Log the performance data
        level = logging.INFO if success else logging.WARNING
        message = f"Performance: {operation_name} completed in {duration_seconds:.3f}s"
        if not success:
            message += f" with error: {error}"

        self.logger.log(level, message, extra={'extra_fields': extra_fields})

    def get_metrics_summary(self) -> Dict[str, Any]:
        """Get summary of performance metrics"""
        with self._lock:
            summary = {}
            for operation, metrics in self._metrics.items():
                avg_time = metrics['total_time'] / metrics['count'] if metrics['count'] > 0 else 0
                success_rate = metrics['success_count'] / metrics['count'] if metrics['count'] > 0 else 0

                summary[operation] = {
                    'total_calls': metrics['count'],
                    'success_calls': metrics['success_count'],
                    'error_calls': metrics['error_count'],
                    'success_rate': success_rate,
                    'average_duration_seconds': avg_time,
                    'total_duration_seconds': metrics['total_time']
                }

            return summary

    def log_metrics_summary(self):
        """Log current metrics summary"""
        summary = self.get_metrics_summary()

        self.logger.info(
            "Performance metrics summary",
            extra={'extra_fields': {'metric_type': 'summary', 'metrics': summary}}
        )

class LogManager:
    """
    Central log management class that handles all logging configuration
    """

    def __init__(self):
        self.loggers = {}
        self.performance_logger = None
        self._configured = False

    def setup_logging(self, 
                     name: str = "openwebui-proxy",
                     log_level: str = "INFO",
                     log_dir: str = "/app/logs",
                     console_output: bool = True,
                     json_format: bool = False,
                     max_file_size: int = 10 * 1024 * 1024,  # 10MB
                     backup_count: int = 5) -> logging.Logger:
        """
        Setup comprehensive logging configuration

        Args:
            name: Logger name
            log_level: Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
            log_dir: Directory for log files
            console_output: Whether to output to console
            json_format: Whether to use JSON formatting
            max_file_size: Maximum size of log files before rotation
            backup_count: Number of backup files to keep

        Returns:
            Configured logger instance
        """

        # Create log directory
        log_path = Path(log_dir)
        log_path.mkdir(parents=True, exist_ok=True)

        # Get or create logger
        logger = logging.getLogger(name)
        logger.setLevel(getattr(logging, log_level.upper()))

        # Clear existing handlers to avoid duplicates
        logger.handlers.clear()

        # Create formatters
        if json_format:
            file_formatter = JSONFormatter()
            console_formatter = JSONFormatter()
        else:
            file_formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(module)s:%(funcName)s:%(lineno)d - %(message)s'
            )
            console_formatter = ColoredFormatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
            )

        # File handler with rotation
        file_handler = logging.handlers.RotatingFileHandler(
            filename=log_path / f"{name}.log",
            maxBytes=max_file_size,
            backupCount=backup_count,
            encoding='utf-8'
        )
        file_handler.setFormatter(file_formatter)
        file_handler.setLevel(logging.DEBUG)  # File gets all levels
        logger.addHandler(file_handler)

        # Error file handler (separate file for errors)
        error_handler = logging.handlers.RotatingFileHandler(
            filename=log_path / f"{name}_errors.log",
            maxBytes=max_file_size,
            backupCount=backup_count,
            encoding='utf-8'
        )
        error_handler.setFormatter(file_formatter)
        error_handler.setLevel(logging.ERROR)
        logger.addHandler(error_handler)

        # JSON structured log handler (for monitoring systems)
        json_handler = logging.handlers.RotatingFileHandler(
            filename=log_path / f"{name}_structured.json",
            maxBytes=max_file_size,
            backupCount=backup_count,
            encoding='utf-8'
        )
        json_handler.setFormatter(JSONFormatter())
        json_handler.setLevel(logging.INFO)
        logger.addHandler(json_handler)

        # Console handler
        if console_output:
            console_handler = logging.StreamHandler(sys.stdout)
            console_handler.setFormatter(console_formatter)
            console_handler.setLevel(getattr(logging, log_level.upper()))
            logger.addHandler(console_handler)

        # Store logger reference
        self.loggers[name] = logger

        # Setup performance logger
        if not self.performance_logger:
            self.performance_logger = PerformanceLogger(logger)

        self._configured = True

        # Log initial setup message
        logger.info(f"Logging system initialized - Level: {log_level}, Directory: {log_dir}")

        return logger

    def get_agent_logger(self, agent_name: str) -> AgentLoggerAdapter:
        """Get agent-specific logger adapter"""
        base_logger = self.loggers.get("openwebui-proxy")
        if not base_logger:
            base_logger = self.setup_logging()

        return AgentLoggerAdapter(base_logger, agent_name)

    def get_request_logger(self, request_id: str, user_id: str = None) -> RequestLoggerAdapter:
        """Get request-specific logger adapter"""
        base_logger = self.loggers.get("openwebui-proxy")
        if not base_logger:
            base_logger = self.setup_logging()

        return RequestLoggerAdapter(base_logger, request_id, user_id)

    def get_performance_logger(self) -> PerformanceLogger:
        """Get performance logger"""
        if not self.performance_logger:
            base_logger = self.loggers.get("openwebui-proxy")
            if not base_logger:
                base_logger = self.setup_logging()
            self.performance_logger = PerformanceLogger(base_logger)

        return self.performance_logger

    def log_system_info(self):
        """Log system information for debugging"""
        logger = self.loggers.get("openwebui-proxy")
        if not logger:
            return

        import platform
        import psutil

        system_info = {
            'platform': platform.platform(),
            'python_version': platform.python_version(),
            'cpu_count': psutil.cpu_count(),
            'memory_total_gb': psutil.virtual_memory().total / (1024**3),
            'disk_usage_gb': psutil.disk_usage('/').total / (1024**3),
            'working_directory': os.getcwd()
        }

        logger.info(
            "System information logged",
            extra={'extra_fields': {'metric_type': 'system_info', **system_info}}
        )

    def setup_exception_logging(self):
        """Setup global exception logging"""
        def handle_exception(exc_type, exc_value, exc_traceback):
            if issubclass(exc_type, KeyboardInterrupt):
                sys.__excepthook__(exc_type, exc_value, exc_traceback)
                return

            logger = self.loggers.get("openwebui-proxy")
            if logger:
                logger.critical(
                    "Uncaught exception",
                    exc_info=(exc_type, exc_value, exc_traceback),
                    extra={'extra_fields': {'metric_type': 'uncaught_exception'}}
                )

        sys.excepthook = handle_exception

    def cleanup_old_logs(self, days_to_keep: int = 30):
        """Clean up old log files"""
        logger = self.loggers.get("openwebui-proxy")
        if not logger:
            return

        from datetime import timedelta

        cutoff_date = datetime.now() - timedelta(days=days_to_keep)

        for log_dir in ["/app/logs", "/app/memory"]:
            log_path = Path(log_dir)
            if not log_path.exists():
                continue

            deleted_count = 0
            for log_file in log_path.glob("*.log*"):
                if log_file.stat().st_mtime < cutoff_date.timestamp():
                    try:
                        log_file.unlink()
                        deleted_count += 1
                    except Exception as e:
                        logger.warning(f"Failed to delete old log file {log_file}: {e}")

            if deleted_count > 0:
                logger.info(f"Cleaned up {deleted_count} old log files from {log_dir}")

# Global log manager instance
log_manager = LogManager()

def setup_logger(name: str = "openwebui-proxy", **kwargs) -> logging.Logger:
    """
    Convenience function to setup logging

    Args:
        name: Logger name
        **kwargs: Additional arguments passed to LogManager.setup_logging

    Returns:
        Configured logger instance
    """

    # Import config here to avoid circular imports
    try:
        from config import Config

        # Use config values as defaults
        defaults = {
            'log_level': Config.LOG_LEVEL,
            'log_dir': Config.LOG_DIR,
            'max_file_size': Config.LOG_MAX_SIZE,
            'backup_count': Config.LOG_BACKUP_COUNT,
            'console_output': True,
            'json_format': Config.ENVIRONMENT == 'production'
        }

        # Override with provided kwargs
        defaults.update(kwargs)
        kwargs = defaults

    except ImportError:
        # Fallback if config is not available
        pass

    logger = log_manager.setup_logging(name, **kwargs)

    # Setup additional logging features
    log_manager.setup_exception_logging()
    log_manager.log_system_info()

    return logger

def get_agent_logger(agent_name: str) -> AgentLoggerAdapter:
    """Get agent-specific logger"""
    return log_manager.get_agent_logger(agent_name)

def get_request_logger(request_id: str, user_id: str = None) -> RequestLoggerAdapter:
    """Get request-specific logger"""
    return log_manager.get_request_logger(request_id, user_id)

def get_performance_logger() -> PerformanceLogger:
    """Get performance logger"""
    return log_manager.get_performance_logger()

# Utility functions for common logging patterns
def log_function_call(logger: logging.Logger):
    """Decorator to log function calls"""
    def decorator(func):
        def wrapper(*args, **kwargs):
            logger.debug(f"Calling function: {func.__name__}")
            try:
                result = func(*args, **kwargs)
                logger.debug(f"Function {func.__name__} completed successfully")
                return result
            except Exception as e:
                logger.error(f"Function {func.__name__} failed: {e}", exc_info=True)
                raise
        return wrapper
    return decorator

def log_async_function_call(logger: logging.Logger):
    """Decorator to log async function calls"""
    def decorator(func):
        async def wrapper(*args, **kwargs):
            logger.debug(f"Calling async function: {func.__name__}")
            try:
                result = await func(*args, **kwargs)
                logger.debug(f"Async function {func.__name__} completed successfully")
                return result
            except Exception as e:
                logger.error(f"Async function {func.__name__} failed: {e}", exc_info=True)
                raise
        return wrapper
    return decorator

# Example usage and testing
if __name__ == "__main__":
    # Test the logging system
    logger = setup_logger("test-logger", log_level="DEBUG")

    logger.info("Testing logging system")
    logger.debug("Debug message")
    logger.warning("Warning message")
    logger.error("Error message")

    # Test agent logger
    agent_logger = get_agent_logger("chatgpt")
    agent_logger.info("Agent logger test")
    agent_logger.log_interaction("Hello", "Hi there!", 1.5)
    agent_logger.log_browser_action("click", "button.submit", True)

    # Test performance logger
    perf_logger = get_performance_logger()
    with perf_logger.timer("test_operation", agent="chatgpt"):
        import time
        time.sleep(0.1)

    perf_logger.log_metrics_summary()

    print("Logging system test completed!")
