import asyncio
import json
import logging
import os
from datetime import datetime
from typing import Dict, List, Optional

import uvicorn
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from agents.chatgpt import ChatGPTAgent
from agents.genspark import GenSparkAgent
from agents.kindroid import KindroidAgent
from agents.suno import SunoAgent
from config import Config
from logger import setup_logger

# Initialize logger
logger = setup_logger()

# Pydantic models for OpenAI compatibility
class ChatMessage(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    model: str
    messages: List[ChatMessage]
    temperature: Optional[float] = 0.7
    max_tokens: Optional[int] = 1000
    stream: Optional[bool] = False

class ChatResponse(BaseModel):
    id: str
    object: str = "chat.completion"
    created: int
    model: str
    choices: List[Dict]
    usage: Dict

class HealthResponse(BaseModel):
    status: str
    timestamp: str
    agents: Dict[str, Dict]

# Initialize FastAPI app
app = FastAPI(
    title="OpenWebUI Proxy Bridge",
    description="Modular agent bridge for OpenWebUI integration",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Agent registry
agents = {}

@app.on_event("startup")
async def startup_event():
    """Initialize agents on startup"""
    global agents

    logger.info("🚀 Starting OpenWebUI Proxy Bridge...")
    logger.info("Initializing agents...")

    try:
        agents = {
            "chatgpt": ChatGPTAgent(),
            "genspark": GenSparkAgent(),
            "kindroid": KindroidAgent(),
            "suno": SunoAgent()
        }

        # Initialize browser sessions for all agents
        for name, agent in agents.items():
            try:
                logger.info(f"Initializing {name} agent...")
                await agent.initialize()
                logger.info(f"✅ {name} agent initialized successfully")
            except Exception as e:
                logger.error(f"❌ Failed to initialize {name} agent: {e}")
                # Continue with other agents even if one fails

        logger.info("🎯 Agent initialization complete!")

    except Exception as e:
        logger.error(f"Failed to initialize agents: {e}")

@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown"""
    logger.info("🛑 Shutting down OpenWebUI Proxy Bridge...")
    logger.info("Cleaning up agents...")

    for name, agent in agents.items():
        try:
            await agent.cleanup()
            logger.info(f"✅ {name} agent cleaned up")
        except Exception as e:
            logger.error(f"❌ Failed to cleanup {name} agent: {e}")

    logger.info("👋 Shutdown complete!")

@app.get("/", response_model=Dict)
async def root():
    """Root endpoint with service information"""
    return {
        "service": "OpenWebUI Proxy Bridge",
        "version": "1.0.0",
        "status": "running",
        "endpoints": {
            "health": "/health",
            "chat": "/chat",
            "docs": "/docs"
        },
        "supported_models": ["chatgpt", "genspark", "kindroid", "suno"]
    }

@app.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    logger.info("Health check requested")

    agent_status = {}

    for name, agent in agents.items():
        try:
            status = await agent.health_check()
            agent_status[name] = status
        except Exception as e:
            agent_status[name] = {
                "status": "error", 
                "error": str(e),
                "agent": name,
                "browser_active": False
            }

    overall_status = "healthy" if any(
        agent.get("status") == "healthy" for agent in agent_status.values()
    ) else "degraded"

    return HealthResponse(
        status=overall_status,
        timestamp=datetime.utcnow().isoformat(),
        agents=agent_status
    )

@app.post("/chat", response_model=ChatResponse)
async def chat_completion(request: ChatRequest):
    """Main chat endpoint - OpenAI compatible"""

    logger.info(f"Chat request received for model: {request.model}")

    # Extract agent from model name
    model_parts = request.model.split("-")
    agent_name = model_parts[0] if model_parts else "chatgpt"

    # Validate agent exists
    if agent_name not in agents:
        available_agents = list(agents.keys())
        logger.error(f"Agent '{agent_name}' not found. Available: {available_agents}")
        raise HTTPException(
            status_code=400, 
            detail=f"Agent '{agent_name}' not found. Available agents: {available_agents}"
        )

    agent = agents[agent_name]

    # Check if agent is initialized
    if not agent.is_initialized:
        logger.error(f"Agent '{agent_name}' is not initialized")
        raise HTTPException(
            status_code=503, 
            detail=f"Agent '{agent_name}' is not available. Check /health for status."
        )

    try:
        # Extract the last user message
        user_message = ""
        for msg in reversed(request.messages):
            if msg.role == "user":
                user_message = msg.content
                break

        if not user_message:
            raise HTTPException(status_code=400, detail="No user message found in request")

        logger.info(f"Processing message with {agent_name}: {user_message[:100]}...")

        # Get response from agent
        response_text = await agent.process_message(user_message)

        if not response_text:
            response_text = "No response received from agent"

        # Create OpenAI-compatible response
        response_id = f"chatcmpl-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}"

        response = ChatResponse(
            id=response_id,
            created=int(datetime.utcnow().timestamp()),
            model=request.model,
            choices=[{
                "index": 0,
                "message": {
                    "role": "assistant",
                    "content": response_text
                },
                "finish_reason": "stop"
            }],
            usage={
                "prompt_tokens": len(user_message.split()),
                "completion_tokens": len(response_text.split()),
                "total_tokens": len(user_message.split()) + len(response_text.split())
            }
        )

        # Log the interaction
        log_interaction(agent_name, user_message, response_text, response_id)

        logger.info(f"✅ Successfully processed message with {agent_name}")
        return response

    except HTTPException:
        # Re-raise HTTP exceptions
        raise
    except Exception as e:
        logger.error(f"❌ Error processing chat request with {agent_name}: {e}")
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

@app.get("/models")
async def list_models():
    """List available models (OpenAI compatible)"""
    models = []

    for agent_name in agents.keys():
        models.append({
            "id": agent_name,
            "object": "model",
            "created": int(datetime.utcnow().timestamp()),
            "owned_by": "openwebui-proxy-bridge",
            "permission": [],
            "root": agent_name,
            "parent": None
        })

    return {
        "object": "list",
        "data": models
    }

@app.get("/agents/{agent_name}/status")
async def get_agent_status(agent_name: str):
    """Get status of specific agent"""
    if agent_name not in agents:
        raise HTTPException(status_code=404, detail=f"Agent '{agent_name}' not found")

    try:
        status = await agents[agent_name].health_check()
        return status
    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
            "agent": agent_name
        }

@app.post("/agents/{agent_name}/reinitialize")
async def reinitialize_agent(agent_name: str):
    """Reinitialize a specific agent"""
    if agent_name not in agents:
        raise HTTPException(status_code=404, detail=f"Agent '{agent_name}' not found")

    try:
        logger.info(f"Reinitializing {agent_name} agent...")

        # Cleanup existing agent
        await agents[agent_name].cleanup()

        # Reinitialize
        await agents[agent_name].initialize()

        logger.info(f"✅ {agent_name} agent reinitialized successfully")

        return {
            "status": "success",
            "message": f"Agent '{agent_name}' reinitialized successfully",
            "timestamp": datetime.utcnow().isoformat()
        }

    except Exception as e:
        logger.error(f"❌ Failed to reinitialize {agent_name} agent: {e}")
        raise HTTPException(status_code=500, detail=f"Failed to reinitialize agent: {str(e)}")

def log_interaction(agent_name: str, user_message: str, response: str, response_id: str):
    """Log interaction to memory"""
    try:
        # Ensure memory directory exists
        memory_dir = "/app/memory"
        os.makedirs(memory_dir, exist_ok=True)

        # Create daily log file
        memory_file = f"{memory_dir}/{agent_name}_{datetime.utcnow().strftime('%Y%m%d')}.json"

        interaction = {
            "id": response_id,
            "timestamp": datetime.utcnow().isoformat(),
            "agent": agent_name,
            "user_message": user_message,
            "response": response,
            "response_length": len(response),
            "user_message_length": len(user_message)
        }

        # Load existing data or create new
        if os.path.exists(memory_file):
            try:
                with open(memory_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
            except (json.JSONDecodeError, FileNotFoundError):
                data = {"interactions": []}
        else:
            data = {"interactions": []}

        # Add new interaction
        data["interactions"].append(interaction)

        # Save back to file
        with open(memory_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        logger.info(f"💾 Interaction logged to {memory_file}")

    except Exception as e:
        logger.error(f"❌ Failed to log interaction: {e}")

# Error handlers
@app.exception_handler(404)
async def not_found_handler(request: Request, exc):
    return {
        "error": "Not Found",
        "message": f"The requested endpoint {request.url.path} was not found",
        "status_code": 404
    }

@app.exception_handler(500)
async def internal_error_handler(request: Request, exc):
    logger.error(f"Internal server error: {exc}")
    return {
        "error": "Internal Server Error",
        "message": "An internal server error occurred",
        "status_code": 500
    }

if __name__ == "__main__":
    # Run the server
    logger.info("🚀 Starting OpenWebUI Proxy Bridge server...")

    uvicorn.run(
        "main:app",
        host=Config.HOST,
        port=Config.PORT,
        reload=Config.DEBUG,
        log_level="info" if not Config.DEBUG else "debug",
        access_log=True
    )
