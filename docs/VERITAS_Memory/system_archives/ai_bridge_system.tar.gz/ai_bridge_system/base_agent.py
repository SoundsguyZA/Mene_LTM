import asyncio
import logging
import time
import json
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, List, Union
from datetime import datetime, timedelta
from contextlib import asynccontextmanager

from playwright.async_api import async_playwright, Browser, BrowserContext, Page, TimeoutError as PlaywrightTimeoutError
from config import Config
from logger import get_agent_logger, get_performance_logger

class AgentError(Exception):
    """Base exception for agent-related errors"""
    pass

class AgentInitializationError(AgentError):
    """Raised when agent initialization fails"""
    pass

class AgentAuthenticationError(AgentError):
    """Raised when agent authentication fails"""
    pass

class AgentTimeoutError(AgentError):
    """Raised when agent operations timeout"""
    pass

class AgentBrowserError(AgentError):
    """Raised when browser automation fails"""
    pass

class BaseAgent(ABC):
    """
    Base class for all AI service agents

    Provides common functionality for browser automation, session management,
    error handling, and logging. All service-specific agents inherit from this class.

    Features:
    - Browser automation with Playwright
    - Session persistence and management
    - Automatic retry mechanisms
    - Comprehensive logging and monitoring
    - Health checking and status reporting
    - Error handling and recovery
    - Performance metrics collection
    """

    def __init__(self, agent_name: str):
        """
        Initialize base agent

        Args:
            agent_name: Unique name for this agent (e.g., 'chatgpt', 'genspark')
        """
        self.agent_name = agent_name
        self.config = Config.get_agent_config(agent_name)

        # Browser components
        self.playwright = None
        self.browser: Optional[Browser] = None
        self.context: Optional[BrowserContext] = None
        self.page: Optional[Page] = None

        # State management
        self.is_initialized = False
        self.is_authenticated = False
        self.last_activity = None
        self.initialization_time = None
        self.session_id = None

        # Error tracking
        self.error_count = 0
        self.last_error = None
        self.consecutive_errors = 0
        self.max_consecutive_errors = 5

        # Performance tracking
        self.request_count = 0
        self.total_response_time = 0
        self.last_request_time = None

        # Logging
        self.logger = get_agent_logger(agent_name)
        self.performance_logger = get_performance_logger()

        # Validate configuration
        self._validate_config()

        self.logger.info(f"Agent {agent_name} initialized with config validation")

    def _validate_config(self):
        """Validate agent configuration"""
        if not self.config:
            raise AgentInitializationError(f"No configuration found for agent {self.agent_name}")

        required_fields = ['email', 'password', 'url']
        missing_fields = [field for field in required_fields if not self.config.get(field)]

        if missing_fields:
            raise AgentInitializationError(
                f"Missing required configuration fields for {self.agent_name}: {missing_fields}"
            )

        self.logger.info("Configuration validation passed")

    async def initialize(self):
        """
        Initialize browser and authenticate with the service

        Raises:
            AgentInitializationError: If initialization fails
        """
        if self.is_initialized:
            self.logger.warning("Agent already initialized, skipping")
            return

        self.logger.info(f"Initializing {self.agent_name} agent...")

        try:
            with self.performance_logger.timer(f"{self.agent_name}_initialization"):
                # Start Playwright
                await self._start_playwright()

                # Launch browser
                await self._launch_browser()

                # Create context and page
                await self._create_context()
                await self._create_page()

                # Configure page
                await self._configure_page()

                # Perform authentication
                await self._authenticate()

                # Mark as initialized
                self.is_initialized = True
                self.initialization_time = datetime.utcnow()
                self.session_id = f"{self.agent_name}_{int(time.time())}"
                self.last_activity = datetime.utcnow()

                self.logger.info(f"✅ {self.agent_name} agent initialized successfully")

        except Exception as e:
            self.logger.error(f"❌ Failed to initialize {self.agent_name} agent: {e}")
            await self.cleanup()
            raise AgentInitializationError(f"Initialization failed: {str(e)}") from e

    async def _start_playwright(self):
        """Start Playwright instance"""
        self.logger.debug("Starting Playwright...")
        self.playwright = await async_playwright().start()
        self.logger.debug("Playwright started successfully")

    async def _launch_browser(self):
        """Launch browser with configured options"""
        self.logger.debug("Launching browser...")

        browser_args = self.config.get('browser_args', Config.BROWSER_ARGS)

        self.browser = await self.playwright.chromium.launch(
            headless=Config.HEADLESS,
            args=browser_args,
            slow_mo=50 if Config.DEBUG else 0  # Slow down in debug mode
        )

        self.logger.debug("Browser launched successfully")

    async def _create_context(self):
        """Create browser context with configured options"""
        self.logger.debug("Creating browser context...")

        viewport = self.config.get('viewport', {
            'width': Config.VIEWPORT_WIDTH,
            'height': Config.VIEWPORT_HEIGHT
        })

        user_agent = self.config.get('user_agent', Config.USER_AGENT)

        self.context = await self.browser.new_context(
            viewport=viewport,
            user_agent=user_agent,
            locale='en-US',
            timezone_id='America/New_York',
            permissions=['notifications'],
            ignore_https_errors=True
        )

        # Set up request/response logging in debug mode
        if Config.DEBUG:
            self.context.on('request', self._log_request)
            self.context.on('response', self._log_response)

        self.logger.debug("Browser context created successfully")

    async def _create_page(self):
        """Create new page in the browser context"""
        self.logger.debug("Creating new page...")

        self.page = await self.context.new_page()

        # Set timeouts
        self.page.set_default_timeout(self.config.get('timeout', Config.BROWSER_TIMEOUT))
        self.page.set_default_navigation_timeout(self.config.get('page_load_timeout', Config.PAGE_LOAD_TIMEOUT))

        self.logger.debug("Page created successfully")

    async def _configure_page(self):
        """Configure page with additional settings"""
        self.logger.debug("Configuring page...")

        # Block unnecessary resources to speed up loading
        await self.page.route("**/*.{png,jpg,jpeg,gif,svg,ico,woff,woff2}", lambda route: route.abort())

        # Add custom JavaScript to avoid detection
        await self.page.add_init_script("""
            Object.defineProperty(navigator, 'webdriver', {
                get: () => undefined,
            });

            Object.defineProperty(navigator, 'plugins', {
                get: () => [1, 2, 3, 4, 5],
            });

            Object.defineProperty(navigator, 'languages', {
                get: () => ['en-US', 'en'],
            });

            window.chrome = {
                runtime: {},
            };
        """)

        self.logger.debug("Page configured successfully")

    async def _authenticate(self):
        """Authenticate with the service"""
        self.logger.info("Starting authentication process...")

        try:
            with self.performance_logger.timer(f"{self.agent_name}_authentication"):
                await self.login()
                self.is_authenticated = True
                self.logger.info("✅ Authentication successful")

        except Exception as e:
            self.logger.error(f"❌ Authentication failed: {e}")
            raise AgentAuthenticationError(f"Authentication failed: {str(e)}") from e

    def _log_request(self, request):
        """Log browser requests in debug mode"""
        if Config.DEBUG:
            self.logger.debug(f"Request: {request.method} {request.url}")

    def _log_response(self, response):
        """Log browser responses in debug mode"""
        if Config.DEBUG:
            self.logger.debug(f"Response: {response.status} {response.url}")

    async def cleanup(self):
        """
        Cleanup browser resources and reset state
        """
        self.logger.info(f"Cleaning up {self.agent_name} agent...")

        try:
            # Close page
            if self.page:
                await self.page.close()
                self.page = None
                self.logger.debug("Page closed")

            # Close context
            if self.context:
                await self.context.close()
                self.context = None
                self.logger.debug("Context closed")

            # Close browser
            if self.browser:
                await self.browser.close()
                self.browser = None
                self.logger.debug("Browser closed")

            # Stop Playwright
            if self.playwright:
                await self.playwright.stop()
                self.playwright = None
                self.logger.debug("Playwright stopped")

            # Reset state
            self.is_initialized = False
            self.is_authenticated = False
            self.session_id = None

            self.logger.info(f"✅ {self.agent_name} agent cleaned up successfully")

        except Exception as e:
            self.logger.error(f"❌ Error during cleanup: {e}")

    async def health_check(self) -> Dict[str, Any]:
        """
        Perform health check and return status

        Returns:
            Dictionary with health status information
        """
        health_status = {
            "agent": self.agent_name,
            "status": "unknown",
            "initialized": self.is_initialized,
            "authenticated": self.is_authenticated,
            "browser_active": False,
            "last_activity": self.last_activity.isoformat() if self.last_activity else None,
            "session_id": self.session_id,
            "error_count": self.error_count,
            "consecutive_errors": self.consecutive_errors,
            "request_count": self.request_count,
            "average_response_time": self.get_average_response_time(),
            "uptime_seconds": self.get_uptime_seconds()
        }

        try:
            # Check browser connection
            if self.browser and self.browser.is_connected():
                health_status["browser_active"] = True

            # Check page accessibility
            if self.page and self.is_initialized:
                # Try to evaluate simple JavaScript
                await self.page.evaluate("() => document.readyState")
                health_status["status"] = "healthy"
            else:
                health_status["status"] = "not_initialized"

        except Exception as e:
            health_status["status"] = "error"
            health_status["error"] = str(e)
            self.logger.warning(f"Health check failed: {e}")

        return health_status

    def get_average_response_time(self) -> float:
        """Get average response time for requests"""
        if self.request_count == 0:
            return 0.0
        return self.total_response_time / self.request_count

    def get_uptime_seconds(self) -> Optional[float]:
        """Get uptime in seconds since initialization"""
        if not self.initialization_time:
            return None
        return (datetime.utcnow() - self.initialization_time).total_seconds()

    async def process_message(self, message: str) -> str:
        """
        Process user message and return response

        Args:
            message: User message to process

        Returns:
            Agent response string

        Raises:
            AgentError: If processing fails
        """
        if not self.is_initialized:
            raise AgentError(f"Agent {self.agent_name} is not initialized")

        if not self.is_authenticated:
            raise AgentError(f"Agent {self.agent_name} is not authenticated")

        self.logger.info(f"Processing message: {message[:100]}...")

        start_time = time.time()

        try:
            with self.performance_logger.timer(f"{self.agent_name}_message_processing", message_length=len(message)):
                # Implement retry logic
                max_retries = self.config.get('max_retries', Config.MAX_RETRIES)
                retry_delay = self.config.get('retry_delay', Config.RETRY_DELAY)

                for attempt in range(max_retries + 1):
                    try:
                        # Call the abstract method implemented by subclasses
                        response = await self._process_message_impl(message)

                        # Update metrics
                        response_time = time.time() - start_time
                        self.request_count += 1
                        self.total_response_time += response_time
                        self.last_request_time = datetime.utcnow()
                        self.last_activity = datetime.utcnow()
                        self.consecutive_errors = 0  # Reset error count on success

                        # Log successful interaction
                        self.logger.log_interaction(
                            user_message=message,
                            response=response,
                            response_time=response_time
                        )

                        self.logger.info(f"✅ Message processed successfully in {response_time:.2f}s")
                        return response

                    except Exception as e:
                        self.consecutive_errors += 1
                        self.error_count += 1
                        self.last_error = str(e)

                        if attempt < max_retries:
                            self.logger.warning(f"Attempt {attempt + 1} failed, retrying in {retry_delay}s: {e}")
                            await asyncio.sleep(retry_delay)
                        else:
                            self.logger.error(f"All {max_retries + 1} attempts failed: {e}")
                            raise

        except Exception as e:
            self.logger.error(f"❌ Failed to process message: {e}")

            # Check if we need to reinitialize due to too many errors
            if self.consecutive_errors >= self.max_consecutive_errors:
                self.logger.warning(f"Too many consecutive errors ({self.consecutive_errors}), reinitializing...")
                try:
                    await self.cleanup()
                    await self.initialize()
                except Exception as reinit_error:
                    self.logger.error(f"Reinitialization failed: {reinit_error}")

            raise AgentError(f"Message processing failed: {str(e)}") from e

    @abstractmethod
    async def login(self):
        """
        Login to the service - must be implemented by subclasses

        This method should handle the authentication process specific to each service.
        It should navigate to the login page, fill credentials, and verify successful login.

        Raises:
            AgentAuthenticationError: If login fails
        """
        pass

    @abstractmethod
    async def _process_message_impl(self, message: str) -> str:
        """
        Process message implementation - must be implemented by subclasses

        This method should handle the actual message processing logic specific to each service.
        It should send the message to the service and return the response.

        Args:
            message: User message to process

        Returns:
            Service response string

        Raises:
            AgentError: If processing fails
        """
        pass

    # Utility methods for browser automation

    async def safe_click(self, selector: str, timeout: int = 5000, wait_for_selector: bool = True) -> bool:
        """
        Safely click an element with error handling

        Args:
            selector: CSS selector for the element
            timeout: Timeout in milliseconds
            wait_for_selector: Whether to wait for selector before clicking

        Returns:
            True if click was successful, False otherwise
        """
        try:
            if wait_for_selector:
                await self.page.wait_for_selector(selector, timeout=timeout)

            await self.page.click(selector, timeout=timeout)

            self.logger.log_browser_action("click", selector, True)
            return True

        except Exception as e:
            self.logger.log_browser_action("click", selector, False, error=str(e))
            return False

    async def safe_fill(self, selector: str, text: str, timeout: int = 5000, clear_first: bool = True) -> bool:
        """
        Safely fill an input field with error handling

        Args:
            selector: CSS selector for the input field
            text: Text to fill
            timeout: Timeout in milliseconds
            clear_first: Whether to clear the field first

        Returns:
            True if fill was successful, False otherwise
        """
        try:
            await self.page.wait_for_selector(selector, timeout=timeout)

            if clear_first:
                await self.page.fill(selector, "")

            await self.page.fill(selector, text)

            self.logger.log_browser_action("fill", selector, True, text_length=len(text))
            return True

        except Exception as e:
            self.logger.log_browser_action("fill", selector, False, error=str(e))
            return False

    async def safe_wait_for_selector(self, selector: str, timeout: int = 5000, state: str = "visible"):
        """
        Safely wait for selector with error handling

        Args:
            selector: CSS selector to wait for
            timeout: Timeout in milliseconds
            state: Element state to wait for ('visible', 'hidden', 'attached', 'detached')

        Returns:
            Element handle if found, None otherwise
        """
        try:
            element = await self.page.wait_for_selector(selector, timeout=timeout, state=state)
            self.logger.log_browser_action("wait_for_selector", selector, True, state=state)
            return element

        except PlaywrightTimeoutError:
            self.logger.log_browser_action("wait_for_selector", selector, False, error="timeout", state=state)
            return None
        except Exception as e:
            self.logger.log_browser_action("wait_for_selector", selector, False, error=str(e), state=state)
            return None

    async def safe_navigate(self, url: str, timeout: int = 30000, wait_until: str = "domcontentloaded") -> bool:
        """
        Safely navigate to URL with error handling

        Args:
            url: URL to navigate to
            timeout: Timeout in milliseconds
            wait_until: When to consider navigation complete

        Returns:
            True if navigation was successful, False otherwise
        """
        try:
            await self.page.goto(url, timeout=timeout, wait_until=wait_until)
            self.logger.log_browser_action("navigate", url, True, wait_until=wait_until)
            return True

        except Exception as e:
            self.logger.log_browser_action("navigate", url, False, error=str(e))
            return False

    async def safe_evaluate(self, script: str, timeout: int = 5000):
        """
        Safely evaluate JavaScript with error handling

        Args:
            script: JavaScript code to evaluate
            timeout: Timeout in milliseconds

        Returns:
            Evaluation result or None if failed
        """
        try:
            result = await self.page.evaluate(script)
            self.logger.log_browser_action("evaluate", script[:50] + "...", True)
            return result

        except Exception as e:
            self.logger.log_browser_action("evaluate", script[:50] + "...", False, error=str(e))
            return None

    async def wait_for_response_completion(self, timeout: int = 60000):
        """
        Wait for page to complete loading responses

        Args:
            timeout: Timeout in milliseconds
        """
        try:
            # Wait for network to be idle
            await self.page.wait_for_load_state("networkidle", timeout=timeout)

            # Additional wait for dynamic content
            await asyncio.sleep(1)

            self.logger.log_browser_action("wait_for_completion", "networkidle", True)

        except Exception as e:
            self.logger.log_browser_action("wait_for_completion", "networkidle", False, error=str(e))

    async def take_screenshot(self, path: str = None) -> Optional[bytes]:
        """
        Take screenshot for debugging

        Args:
            path: Optional file path to save screenshot

        Returns:
            Screenshot bytes or None if failed
        """
        try:
            if not path:
                path = f"/app/logs/{self.agent_name}_screenshot_{int(time.time())}.png"

            screenshot = await self.page.screenshot(path=path, full_page=True)
            self.logger.info(f"Screenshot saved to {path}")
            return screenshot

        except Exception as e:
            self.logger.error(f"Failed to take screenshot: {e}")
            return None

    @asynccontextmanager
    async def error_recovery(self, operation_name: str):
        """
        Context manager for automatic error recovery

        Args:
            operation_name: Name of the operation for logging
        """
        try:
            yield
        except Exception as e:
            self.logger.error(f"Error in {operation_name}: {e}")

            # Take screenshot for debugging
            if Config.DEBUG:
                await self.take_screenshot()

            # Attempt recovery based on error type
            if "timeout" in str(e).lower():
                self.logger.info("Timeout detected, refreshing page...")
                try:
                    await self.page.reload(wait_until="domcontentloaded")
                except:
                    pass

            raise

    def __str__(self):
        """String representation of the agent"""
        return f"{self.__class__.__name__}(name={self.agent_name}, initialized={self.is_initialized})"

    def __repr__(self):
        """Detailed string representation of the agent"""
        return (f"{self.__class__.__name__}("
                f"name={self.agent_name}, "
                f"initialized={self.is_initialized}, "
                f"authenticated={self.is_authenticated}, "
                f"requests={self.request_count}, "
                f"errors={self.error_count})")
