import os
import logging
from typing import Dict, Any, Optional
from pathlib import Path

class Config:
    """
    Configuration management for OpenWebUI Proxy Bridge

    Handles all environment variables, agent configurations, and system settings.
    Provides centralized configuration management with validation and defaults.
    """

    # ========================================
    # SERVER CONFIGURATION
    # ========================================

    HOST = os.getenv("HOST", "0.0.0.0")
    PORT = int(os.getenv("PORT", 8000))
    DEBUG = os.getenv("DEBUG", "false").lower() == "true"

    # Environment detection
    ENVIRONMENT = os.getenv("ENVIRONMENT", "development")  # development, staging, production

    # ========================================
    # BROWSER CONFIGURATION
    # ========================================

    HEADLESS = os.getenv("HEADLESS", "true").lower() == "true"
    BROWSER_TIMEOUT = int(os.getenv("BROWSER_TIMEOUT", 30000))  # 30 seconds
    PAGE_LOAD_TIMEOUT = int(os.getenv("PAGE_LOAD_TIMEOUT", 15000))  # 15 seconds

    # Browser launch arguments
    BROWSER_ARGS = [
        '--no-sandbox',
        '--disable-dev-shm-usage',
        '--disable-blink-features=AutomationControlled',
        '--disable-extensions',
        '--no-first-run',
        '--disable-default-apps',
        '--disable-features=TranslateUI',
        '--disable-ipc-flooding-protection'
    ]

    # User agent for browser sessions
    USER_AGENT = os.getenv(
        "USER_AGENT", 
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    )

    # Browser viewport settings
    VIEWPORT_WIDTH = int(os.getenv("VIEWPORT_WIDTH", 1920))
    VIEWPORT_HEIGHT = int(os.getenv("VIEWPORT_HEIGHT", 1080))

    # ========================================
    # AGENT CREDENTIALS
    # ========================================

    # ChatGPT Configuration
    CHATGPT_EMAIL = os.getenv("CHATGPT_EMAIL")
    CHATGPT_PASSWORD = os.getenv("CHATGPT_PASSWORD")
    CHATGPT_URL = os.getenv("CHATGPT_URL", "https://chat.openai.com")

    # GenSpark Configuration
    GENSPARK_EMAIL = os.getenv("GENSPARK_EMAIL")
    GENSPARK_PASSWORD = os.getenv("GENSPARK_PASSWORD")
    GENSPARK_URL = os.getenv("GENSPARK_URL", "https://www.genspark.ai")

    # Kindroid Configuration
    KINDROID_EMAIL = os.getenv("KINDROID_EMAIL")
    KINDROID_PASSWORD = os.getenv("KINDROID_PASSWORD")
    KINDROID_URL = os.getenv("KINDROID_URL", "https://kindroid.ai")

    # Suno Configuration
    SUNO_EMAIL = os.getenv("SUNO_EMAIL")
    SUNO_PASSWORD = os.getenv("SUNO_PASSWORD")
    SUNO_URL = os.getenv("SUNO_URL", "https://suno.com")

    # ========================================
    # STORAGE CONFIGURATION
    # ========================================

    # Memory storage settings
    MEMORY_DIR = os.getenv("MEMORY_DIR", "/app/memory")
    MEMORY_RETENTION_DAYS = int(os.getenv("MEMORY_RETENTION_DAYS", 30))

    # Log storage settings
    LOG_DIR = os.getenv("LOG_DIR", "/app/logs")
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO").upper()
    LOG_MAX_SIZE = int(os.getenv("LOG_MAX_SIZE", 10 * 1024 * 1024))  # 10MB
    LOG_BACKUP_COUNT = int(os.getenv("LOG_BACKUP_COUNT", 5))

    # ========================================
    # PERFORMANCE CONFIGURATION
    # ========================================

    # Request timeouts
    REQUEST_TIMEOUT = int(os.getenv("REQUEST_TIMEOUT", 120))  # 2 minutes
    RESPONSE_TIMEOUT = int(os.getenv("RESPONSE_TIMEOUT", 180))  # 3 minutes

    # Retry settings
    MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
    RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))  # seconds

    # Concurrent request limits
    MAX_CONCURRENT_REQUESTS = int(os.getenv("MAX_CONCURRENT_REQUESTS", 10))

    # ========================================
    # SECURITY CONFIGURATION
    # ========================================

    # API security
    API_KEY = os.getenv("API_KEY")  # Optional API key for authentication
    ALLOWED_ORIGINS = os.getenv("ALLOWED_ORIGINS", "*").split(",")

    # Rate limiting
    RATE_LIMIT_ENABLED = os.getenv("RATE_LIMIT_ENABLED", "false").lower() == "true"
    RATE_LIMIT_REQUESTS = int(os.getenv("RATE_LIMIT_REQUESTS", 100))
    RATE_LIMIT_WINDOW = int(os.getenv("RATE_LIMIT_WINDOW", 3600))  # 1 hour

    # ========================================
    # MONITORING CONFIGURATION
    # ========================================

    # Health check settings
    HEALTH_CHECK_INTERVAL = int(os.getenv("HEALTH_CHECK_INTERVAL", 60))  # seconds
    HEALTH_CHECK_TIMEOUT = int(os.getenv("HEALTH_CHECK_TIMEOUT", 10))  # seconds

    # Metrics collection
    METRICS_ENABLED = os.getenv("METRICS_ENABLED", "true").lower() == "true"
    METRICS_PORT = int(os.getenv("METRICS_PORT", 9090))

    # ========================================
    # AGENT-SPECIFIC CONFIGURATIONS
    # ========================================

    @classmethod
    def get_agent_config(cls, agent_name: str) -> Dict[str, Any]:
        """
        Get configuration for a specific agent

        Args:
            agent_name: Name of the agent (chatgpt, genspark, kindroid, suno)

        Returns:
            Dictionary containing agent configuration
        """

        base_config = {
            "timeout": cls.BROWSER_TIMEOUT,
            "page_load_timeout": cls.PAGE_LOAD_TIMEOUT,
            "max_retries": cls.MAX_RETRIES,
            "retry_delay": cls.RETRY_DELAY,
            "user_agent": cls.USER_AGENT,
            "viewport": {
                "width": cls.VIEWPORT_WIDTH,
                "height": cls.VIEWPORT_HEIGHT
            },
            "browser_args": cls.BROWSER_ARGS
        }

        agent_configs = {
            "chatgpt": {
                **base_config,
                "email": cls.CHATGPT_EMAIL,
                "password": cls.CHATGPT_PASSWORD,
                "url": cls.CHATGPT_URL,
                "name": "ChatGPT",
                "type": "text_generation",
                "selectors": {
                    "login_button": 'button:has-text("Log in")',
                    "email_input": 'input[name="username"]',
                    "password_input": 'input[name="password"]',
                    "continue_button": 'button:has-text("Continue")',
                    "submit_button": 'button[type="submit"]',
                    "message_input": '#prompt-textarea',
                    "send_button": '[data-testid="send-button"]',
                    "response_container": '[data-message-author-role="assistant"]',
                    "logged_in_indicator": '[data-testid="send-button"]'
                }
            },

            "genspark": {
                **base_config,
                "email": cls.GENSPARK_EMAIL,
                "password": cls.GENSPARK_PASSWORD,
                "url": cls.GENSPARK_URL,
                "name": "GenSpark",
                "type": "ai_search",
                "selectors": {
                    "login_buttons": [
                        'button:has-text("Sign In")',
                        'button:has-text("Login")',
                        'a:has-text("Sign In")',
                        'a:has-text("Login")',
                        '.login-button',
                        '.signin-button'
                    ],
                    "email_inputs": [
                        'input[name="email"]',
                        'input[name="username"]',
                        'input[type="email"]',
                        'input[placeholder*="email"]',
                        'input[placeholder*="Email"]'
                    ],
                    "password_inputs": [
                        'input[name="password"]',
                        'input[type="password"]',
                        'input[placeholder*="password"]',
                        'input[placeholder*="Password"]'
                    ],
                    "submit_buttons": [
                        'button[type="submit"]',
                        'button:has-text("Sign In")',
                        'button:has-text("Login")',
                        'input[type="submit"]'
                    ],
                    "message_inputs": [
                        'textarea[placeholder*="Ask"]',
                        'textarea[placeholder*="question"]',
                        'input[placeholder*="Ask"]',
                        'input[placeholder*="question"]',
                        '.message-input',
                        '.chat-input',
                        'textarea',
                        'input[type="text"]'
                    ],
                    "send_buttons": [
                        'button:has-text("Send")',
                        'button:has-text("Ask")',
                        'button[type="submit"]',
                        '.send-button',
                        '.submit-button',
                        'button[aria-label*="send"]'
                    ],
                    "response_containers": [
                        '.response',
                        '.answer',
                        '.message-content',
                        '.chat-message',
                        '[data-role="assistant"]',
                        '.ai-response'
                    ],
                    "logged_in_indicators": [
                        '.user-menu',
                        '[data-testid="user-avatar"]'
                    ]
                }
            },

            "kindroid": {
                **base_config,
                "email": cls.KINDROID_EMAIL,
                "password": cls.KINDROID_PASSWORD,
                "url": cls.KINDROID_URL,
                "name": "Kindroid",
                "type": "ai_companion",
                "selectors": {
                    "login_buttons": [
                        'button:has-text("Login")',
                        'button:has-text("Sign In")',
                        'a:has-text("Login")',
                        'a:has-text("Sign In")',
                        '.login-btn',
                        '.signin-btn'
                    ],
                    "email_inputs": [
                        'input[name="email"]',
                        'input[type="email"]'
                    ],
                    "password_inputs": [
                        'input[name="password"]',
                        'input[type="password"]'
                    ],
                    "submit_buttons": [
                        'button[type="submit"]',
                        'button:has-text("Login")',
                        'button:has-text("Sign In")',
                        '.login-submit'
                    ],
                    "message_inputs": [
                        '.chat-input',
                        '.message-input',
                        'textarea[placeholder*="message"]',
                        'textarea[placeholder*="chat"]',
                        'input[placeholder*="message"]',
                        'textarea'
                    ],
                    "send_buttons": [
                        'button:has-text("Send")',
                        'button[aria-label*="send"]',
                        '.send-btn',
                        'button[type="submit"]'
                    ],
                    "response_containers": [
                        '.ai-message',
                        '.bot-message',
                        '.response-message',
                        '.chat-response',
                        '[data-role="assistant"]'
                    ],
                    "logged_in_indicators": [
                        '.user-profile',
                        '[data-testid="user-menu"]'
                    ]
                }
            },

            "suno": {
                **base_config,
                "email": cls.SUNO_EMAIL,
                "password": cls.SUNO_PASSWORD,
                "url": cls.SUNO_URL,
                "name": "Suno",
                "type": "music_generation",
                "generation_timeout": 120,  # 2 minutes for music generation
                "selectors": {
                    "login_buttons": [
                        'button:has-text("Sign In")',
                        'button:has-text("Login")',
                        'a:has-text("Sign In")',
                        'a:has-text("Login")',
                        '.signin-button',
                        '.login-button'
                    ],
                    "email_inputs": [
                        'input[name="email"]',
                        'input[type="email"]'
                    ],
                    "password_inputs": [
                        'input[name="password"]',
                        'input[type="password"]'
                    ],
                    "submit_buttons": [
                        'button[type="submit"]',
                        'button:has-text("Sign In")',
                        'button:has-text("Login")',
                        '.submit-btn'
                    ],
                    "prompt_inputs": [
                        'textarea[placeholder*="Describe"]',
                        'textarea[placeholder*="music"]',
                        'input[placeholder*="Describe"]',
                        'input[placeholder*="music"]',
                        '.prompt-input',
                        '.music-input',
                        'textarea',
                        'input[type="text"]'
                    ],
                    "generate_buttons": [
                        'button:has-text("Generate")',
                        'button:has-text("Create")',
                        'button:has-text("Make")',
                        'button[type="submit"]',
                        '.generate-btn',
                        '.create-btn'
                    ],
                    "completion_indicators": [
                        '.generation-complete',
                        '.music-ready',
                        'audio',
                        '.download-btn',
                        'button:has-text("Download")',
                        '.play-btn'
                    ],
                    "result_containers": [
                        '.music-title',
                        '.generation-result',
                        '.music-info',
                        'audio',
                        '.download-link'
                    ],
                    "logged_in_indicators": [
                        '.user-avatar',
                        '[data-testid="user-menu"]'
                    ]
                }
            }
        }

        config = agent_configs.get(agent_name, {})

        # Validate required fields
        if agent_name in agent_configs:
            if not config.get("email") or not config.get("password"):
                logging.warning(f"Missing credentials for {agent_name} agent")

        return config

    @classmethod
    def validate_config(cls) -> Dict[str, Any]:
        """
        Validate configuration and return validation results

        Returns:
            Dictionary with validation results
        """

        validation_results = {
            "valid": True,
            "errors": [],
            "warnings": [],
            "agent_status": {}
        }

        # Validate server configuration
        if cls.PORT < 1 or cls.PORT > 65535:
            validation_results["errors"].append(f"Invalid port number: {cls.PORT}")
            validation_results["valid"] = False

        # Validate browser configuration
        if cls.BROWSER_TIMEOUT < 1000:
            validation_results["warnings"].append("Browser timeout is very low (< 1 second)")

        # Validate directories
        try:
            Path(cls.MEMORY_DIR).mkdir(parents=True, exist_ok=True)
            Path(cls.LOG_DIR).mkdir(parents=True, exist_ok=True)
        except Exception as e:
            validation_results["errors"].append(f"Cannot create directories: {e}")
            validation_results["valid"] = False

        # Validate agent configurations
        agents = ["chatgpt", "genspark", "kindroid", "suno"]

        for agent_name in agents:
            config = cls.get_agent_config(agent_name)
            agent_valid = True
            agent_issues = []

            # Check credentials
            if not config.get("email"):
                agent_issues.append("Missing email credential")
                agent_valid = False

            if not config.get("password"):
                agent_issues.append("Missing password credential")
                agent_valid = False

            # Check URL
            if not config.get("url"):
                agent_issues.append("Missing URL configuration")
                agent_valid = False

            validation_results["agent_status"][agent_name] = {
                "valid": agent_valid,
                "issues": agent_issues
            }

            if not agent_valid:
                validation_results["warnings"].append(f"Agent {agent_name} has configuration issues")

        return validation_results

    @classmethod
    def get_environment_info(cls) -> Dict[str, Any]:
        """
        Get environment information for debugging

        Returns:
            Dictionary with environment information
        """

        return {
            "environment": cls.ENVIRONMENT,
            "debug_mode": cls.DEBUG,
            "host": cls.HOST,
            "port": cls.PORT,
            "headless_browser": cls.HEADLESS,
            "browser_timeout": cls.BROWSER_TIMEOUT,
            "memory_dir": cls.MEMORY_DIR,
            "log_dir": cls.LOG_DIR,
            "log_level": cls.LOG_LEVEL,
            "python_version": os.sys.version,
            "working_directory": os.getcwd(),
            "available_agents": ["chatgpt", "genspark", "kindroid", "suno"],
            "configured_agents": [
                agent for agent in ["chatgpt", "genspark", "kindroid", "suno"]
                if cls.get_agent_config(agent).get("email") and cls.get_agent_config(agent).get("password")
            ]
        }

    @classmethod
    def print_config_summary(cls):
        """Print configuration summary for debugging"""

        print("🔧 OpenWebUI Proxy Bridge Configuration")
        print("=" * 50)

        env_info = cls.get_environment_info()
        validation = cls.validate_config()

        print(f"Environment: {env_info['environment']}")
        print(f"Debug Mode: {env_info['debug_mode']}")
        print(f"Server: {env_info['host']}:{env_info['port']}")
        print(f"Browser: {'Headless' if env_info['headless_browser'] else 'Visible'}")
        print(f"Log Level: {env_info['log_level']}")

        print(f"
📊 Agent Status:")
        for agent, status in validation["agent_status"].items():
            status_icon = "✅" if status["valid"] else "❌"
            print(f"  {status_icon} {agent.capitalize()}")
            if status["issues"]:
                for issue in status["issues"]:
                    print(f"    - {issue}")

        if validation["errors"]:
            print(f"
❌ Configuration Errors:")
            for error in validation["errors"]:
                print(f"  - {error}")

        if validation["warnings"]:
            print(f"
⚠️  Configuration Warnings:")
            for warning in validation["warnings"]:
                print(f"  - {warning}")

        print(f"
✅ Configuration {'Valid' if validation['valid'] else 'Invalid'}")
        print("=" * 50)

# Create configuration instance for easy access
config = Config()

# Validate configuration on import
if __name__ == "__main__":
    Config.print_config_summary()
