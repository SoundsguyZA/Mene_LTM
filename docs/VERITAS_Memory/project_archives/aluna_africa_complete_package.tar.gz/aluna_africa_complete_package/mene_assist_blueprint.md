## 🧠 Mene' Assist – Model Mapping & Agent Blueprint

### 📌 Agent Stack Plan

| Agent Name     | Description                                  | Model                     | Hosted Location        |
|----------------|----------------------------------------------|---------------------------|-------------------------|
| **Mene’**       | Master Orchestrator, user-facing assistant   | GPT-4 / Gemini 1.5 Pro    | Cloud (GCP VM)          |
| **Bonny**       | Research Specialist & Botanical Scientist    | Mistral 7B / Gemini Edu   | Cloud (GCP or Local VM) |
| **Grumpy Steve**| Harsh critic for product/content review      | TinyLlama / LLaMA3        | Local (Ollama)          |
| **Memory Agent**| Handles RAG via AnythingLLM/OpenWebUI        | Scripted (API layer)      | Local (F:\AI_RAM)       |
| **Summarizer**  | Fast doc summarization / compression         | Claude 2 / GPT-3.5 / Mixtral| Cloud or Local         |
| **Voice Synth Agent**| Converts model replies to audio format | Google TTS / Mozilla TTS  | Local / GCP (voice queue)|

---

### 📂 Cloud RAG Storage Blueprint

**Primary Data Location**: `F:\AI_RAM\MeneAssist\`

```
MeneAssist/
├── Agents/                     # Agent definitions, configs, prompts
│   ├── Mene/
│   ├── Bonny/
│   ├── Steve/
├── KnowledgeBase/             # All RAG documents, embeddings
│   ├── Documents/
│   └── Index/                 # LanceDB/Chroma DB
├── Integration/               # Tunnel configs, APIs, sync scripts
├── VoiceAssets/               # TTS output files per agent
├── Logs/                      # Agent actions + data flows
└── Docs/                      # Architecture notes, backups
```

---

### 🔁 Model Mapping Sheet

| Task / Agent Role               | Ideal Model       | Why / Notes                                          |
|--------------------------------|-------------------|------------------------------------------------------|
| Orchestration (Mene’)           | GPT-4 / Gemini     | Best reasoning, top-tier NLP                        |
| Research (Bonny)                | Gemini Edu / Mistral 7B | Gemini for real-world data, Mistral for citations |
| File Summarizing               | Claude 2 / GPT-3.5 | Cost-effective, large context, fast                  |
| Critical Review (Steve)        | TinyLlama / LLaMA3 | Lightweight, direct, efficient                       |
| RAG Interface                  | No model (API)     | Controlled via AnythingLLM/OpenWebUI                 |
| TTS (Mene’, Bonny, Steve)      | Mozilla TTS / GCP  | Mozilla for custom voices, GCP for fast web output  |

---

This plan links **Mene’ Assist** to the Aluna Africa framework as a modular, multi-agent system that can be voice-enabled, locally hosted, and customized at every stage. Ready to integrate into OpenWebUI or future agent stacks like Genspark.

